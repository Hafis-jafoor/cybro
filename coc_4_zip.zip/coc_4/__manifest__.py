{
    'name': 'COC 4',
    'version': '16.0.1.0.0',
    'sequence': 20,
    'depends': ['base', 'mail', 'account_payment'],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
    'data': [
        'security/ir.model.access.csv',
        'views/coc_model.xml',
    ],
}
