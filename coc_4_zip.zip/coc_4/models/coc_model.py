# -*- coding: utf-8 -*-


from odoo import models, fields, api


class CocModel(models.Model):
    """coc 4 project testing"""

    _name = "coc.model"

    partner_id = fields.Many2one('res.partner', string='COC Bot')
